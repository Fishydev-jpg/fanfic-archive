const SUPABASE_URL = 'https://tdtblcqrsnnkdzmvtbfp.supabase.co';
// Keep the publishable key out of source files. Configure it through your
// app's runtime environment or replace this placeholder locally.
const SUPABASE_KEY = 'YOUR_SUPABASE_ANON_KEY';
const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

const WORD_LIMIT = 1000; // Change this number to set your maximum words per page

const contentInput = document.getElementById('content');
const wordCountDisplay = document.getElementById('word-count');
const storyForm = document.getElementById('story-form');
const submitBtn = document.getElementById('submit-btn');

// --- 1. LIVE WORD COUNT & LIMIT ENFORCEMENT ---
contentInput.addEventListener('input', () => {
  const text = contentInput.value.trim();
  // Count words by splitting text on whitespace
  const wordCount = text ? text.split(/\s+/).length : 0;

  wordCountDisplay.textContent = `Words: ${wordCount} / ${WORD_LIMIT}`;

  if (wordCount > WORD_LIMIT) {
    wordCountDisplay.style.color = 'red';
    wordCountDisplay.textContent = `Words: ${wordCount} / ${WORD_LIMIT} (EXCEEDED LIMIT!)`;
    submitBtn.disabled = true; // Block submission if over limit
  } else {
    wordCountDisplay.style.color = 'black';
    submitBtn.disabled = false;
  }
});

// --- 2. UPLOAD TO SUPABASE ---
storyForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const title = document.getElementById('title').value;
  const description = document.getElementById('description').value;
  const tags = document.getElementById('tags').value;
  const content = contentInput.value;

  const { error } = await supabaseClient
    .from('stories')
    .insert([{
      title,
      description,
      tags,
      content
    }]);

  if (error) {
    alert('Error posting story: ' + error.message);
  } else {
    alert('Story successfully published!');
    storyForm.reset();
    wordCountDisplay.textContent = `Words: 0 / ${WORD_LIMIT}`;
  }
});